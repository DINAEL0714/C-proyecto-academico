﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laboratoriocsharp
{
    public partial class frmGestionar : Form

    {
        // creo dos variables X para nos funcionen como validacion de usuario 

        string usuario = "dinael";
        string contraseña = "1234";
        public frmGestionar()
        {
            InitializeComponent();
        }

        // en esta sesion programo el boton  ingresar
        private void btningresar_Click(object sender, EventArgs e)
        {
            // creo una condicion donde evaluo la caja  de texto que recibe y lo comparo 
            // con el valor de mis varibles
            if (lblusuario.Text == usuario && lblcontraseña.Text==contraseña)// condicion
            {
                lbnmensaje.Visible = false; // este es un mensaje que tengo y con la propiedad visible lo gestiono
                Principal obj_menu = new Principal(); // creo un objeto llamado menu y le paso como instancia 
                obj_menu.ShowDialog(); // el formulario principal para se ejecute con una validacion correcta


            }

            // creamos que si no cumple el usuario que se ingresa el mensaje sera visible 

            else
            {
                lbnmensaje.Visible = true;
            }
        }
        
    }
}
