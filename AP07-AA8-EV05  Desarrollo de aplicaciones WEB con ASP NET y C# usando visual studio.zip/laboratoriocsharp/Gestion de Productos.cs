﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laboratoriocsharp
{
    public partial class Gestion_de_Productos : Form
    {
        public Gestion_de_Productos()
        {
            InitializeComponent();
        }

        private void ingresarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = true; // habilitamos el unico que queremos
            panel2.Visible = false;  // desahilitamos los otros si escogen
            panel3.Visible = false; // desahilitamos los otros si escogen
            panel4.Visible = false; // desahilitamos los otros si escogen
        }

        private void consultarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false; // habilitamos el unico que queremos
            panel2.Visible = true;  // desahilitamos los otros si escogen
            panel3.Visible = false; // desahilitamos los otros si escogen
            panel4.Visible = false; // desahilitamos los otros si escogen
        }

        private void modificarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false; // habilitamos el unico que queremos
            panel2.Visible = false;  // desahilitamos los otros si escogen
            panel3.Visible = true; // desahilitamos los otros si escogen
            panel4.Visible = false; // desahilitamos los otros si escogen


            var funciones = new ClassFunciones();
            txtmodificar.DataSource= funciones.ListarProductos();
            txtmodificar.DisplayMember = "proNombre";
            txtmodificar.ValueMember= "proCodigo";

        }

        private void eliminarProductoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false; // habilitamos el unico que queremos
            panel2.Visible = false;  // desahilitamos los otros si escogen
            panel3.Visible = false; // desahilitamos los otros si escogen
            panel4.Visible = true; // desahilitamos los otros si escogen

            var funciones = new ClassFunciones();
            txteliminar.DataSource= funciones.ListarProductos();
            txteliminar.DisplayMember = "proNombre";
            txteliminar.ValueMember= "proCodigo";


        }

        private void btnconsultarpro_Click(object sender, EventArgs e)
        {
            var Productos = new ClassProducto();
            var Tabla = Productos.Listar();
            var NumeroFilas = Tabla.Rows.Count;
            if (NumeroFilas>0)
            {
                for (int i = 0; i<NumeroFilas; i++)
                {
                    String Codigo = Tabla.Rows[i][0].ToString();
                    String Descripcion = Tabla.Rows[i][1].ToString();
                    String Valor = Tabla.Rows[i][2].ToString();
                    String Cantidad = Tabla.Rows[i][3].ToString();
                    String Nombre = Tabla.Rows[i][4].ToString();


                    dataGridView1.Rows.Add(Codigo, Descripcion,Valor ,Cantidad, Nombre);
                }
            }



        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            var RegistrarProducto = new ClassProducto(
                Convert.ToInt32(txtcodigo.Text.Trim()),
                txtnombre.Text,
                txtdescripcion.Text,
                Convert.ToInt32(txtvalor.Text.Trim()),
                Convert.ToInt32(txtcantidad.Text.Trim())

                );
            RegistrarProducto.Registrar();

        }

        private void btnlimpiar_Click(object sender, EventArgs e)
        {
            txtcodigo.Clear();
            txtnombre.Clear();
            txtdescripcion.Clear();
            txtvalor.Clear();
            txtcantidad.Clear();
        }

        private void txtconsultarproducto_SelectedIndexChanged(object sender, EventArgs e)
        {



        }

        private void txtmodificar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Gestion_de_Productos_Load(object sender, EventArgs e)
        {
            var funciones = new ClassFunciones();
            txtconsultarproducto.DataSource= funciones.ListarProductos();
            txtconsultarproducto.DisplayMember = "proNombre";



        }

        private void btneliminar_Click(object sender, EventArgs e)
        {
            var EliminarProducto = new ClassProducto();
            int Codigo = Convert.ToInt32(txteliminar.SelectedValue.ToString());
            EliminarProducto.eliminar(Codigo);
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {

            var ConsultarProducto = new ClassProducto();
            int Codigo = Convert.ToInt32(txtmodificar.SelectedValue.ToString());
            var Tabla = ConsultarProducto.BuscarPorCodigo(Codigo);
            var NumeroFilas = Tabla.Rows.Count;
            if (NumeroFilas>0)
            {
                for (int i = 1; i<NumeroFilas; i++)
                {
                    String Descripcion = Tabla.Rows[i][1].ToString();
                    String Valor =Tabla.Rows[i][2].ToString();
                    String Cantidad =Tabla.Rows[i][3].ToString();

                    txtdescripcion2.Text= Descripcion;
                    txtvalor2.Text=Valor;
                    txtcantidad.Text= Cantidad;

                }
            }
        }

        private void btbguardarca_Click(object sender, EventArgs e)
        {
            var ActualizarProducto = new ClassProducto(
                Convert.ToInt32(txtmodificar.SelectedValue.ToString()),
                txtmodificar.Text,
                txtdescripcion2.Text,
                Convert.ToInt32(txtvalor2.Text.Trim()),
                Convert.ToInt32(txtcantidad.Text.Trim())
                );
            ActualizarProducto.Actualizar();
        }
    }
}
