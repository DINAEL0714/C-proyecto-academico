﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratoriocsharp
{
    internal class ClassFacturaDetalle
    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBNaturVida"].ConnectionString);
        
        public int Numero { get; set; }
        public int Producto { get; set;}
        public int Cantidad { get; set;}

        public ClassFacturaDetalle(int _numero, int _producto, int _cantidad)
        {
            this.Numero = _numero;
            this.Producto=_producto;
            this.Cantidad= _cantidad;   
        }

        public bool Registrar()
        {
            bool i= false;

            try
            {
                using (var command = new SqlCommand("SP_RegistrarFacturDetalle", connection))
                {
                    command.Parameters.AddWithValue("@Numero", this.Numero);
                    command.Parameters.AddWithValue("@Producto", this.Producto);
                    command.Parameters.AddWithValue("@Cantidad", this.Cantidad);
                    command.CommandType= CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    i= true;
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                return false;
            }

            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();


                }
            }
            return i;
        }
    }

}
