﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratoriocsharp
{
    internal interface IFunciones
    {
        int Registrar();
        bool Actualizar();
        bool eliminar( int id);
        DataTable Listar();
        DataTable BuscarPorCodigo(int id);



    }
}
