﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laboratoriocsharp
{
    public partial class frmfactura : Form
    {
        public frmfactura()
        {
            InitializeComponent();
        }

        private void cmbarticulo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnagregar_Click(object sender, EventArgs e)
        {
            var Funciones = new ClassFunciones();
            int Codigo = Convert.ToInt16(cmbarticulo.SelectedValue.ToString());
            String Articulo = cmbarticulo.Text;
            String Cantidad = cmbcantidad.Text;
            int Valor = Funciones.ConsultarPrecio(Codigo); ;
            dataGridView1.Rows.Add(Codigo, Articulo, Cantidad, Valor);

            int NumeroFilas = dataGridView1.Rows.Count;
            int ValorTotal = 0;
            if (NumeroFilas>1)
            {
                for (int i = 0; i<(NumeroFilas-1); i++)
                {
                    int Cant = Convert.ToInt16(dataGridView1.Rows[i].Cells[2].Value.ToString());
                    int Val = Convert.ToInt16(dataGridView1.Rows[i].Cells[3].Value.ToString());
                    ValorTotal+=Cant* Val;
                }
                txttotalfac.Text= ValorTotal.ToString();

            }
            else
            {
                txttotalfac.Text= Valor.ToString();
            }

        }

        private void btnterminar_Click(object sender, EventArgs e)
        {
            int NumeroFilas = dataGridView1.Rows.Count;
            DateTime date = dateTimePicker1.Value;
            int Cliente = Convert.ToInt32(cmbcliente.SelectedValue.ToString());
            int Vendedor = Convert.ToInt32(cmbvendedor.SelectedValue.ToString());
            int ValorTotal = Convert.ToInt32(txttotalfac.Text.ToString());
            var RegistrarFactura = new ClassFactura(date, Cliente, ValorTotal, Vendedor);
            int UltimaFacturas = RegistrarFactura.Registrar();
            for (int i = 0; i<(NumeroFilas-1); i++)
            {
                int Articulo = Convert.ToInt16(dataGridView1.Rows[i].Cells[0].Value.ToString());
                int Cantidad = Convert.ToInt16(dataGridView1.Rows[i].Cells[2].Value.ToString());
                var AgregarProducto = new ClassFacturaDetalle(UltimaFacturas, Articulo, Cantidad);



            }
            System.Windows.Forms.MessageBox.Show(" La factura se registro Exitosamente");


        }

        private void frmfactura_Load(object sender, EventArgs e)
        {
            cmbcantidad.Text= "1";
            var Funciones = new ClassFunciones();

            cmbvendedor.DataSource= Funciones.ListarVendedores();
            cmbvendedor.DisplayMember = "Venid";
            cmbvendedor.ValueMember = "venUsuario";

            cmbcliente.DataSource= Funciones.ListarCliente();
            cmbcliente.DisplayMember = "cliNombre";
            cmbcliente.ValueMember = "cliid";

            cmbarticulo.DataSource= Funciones.ListarProductos();
            cmbarticulo.DisplayMember= "proNombre";
            cmbarticulo.ValueMember= "procodigo";


                

        }

        private void cmbvendedor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
