﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace laboratoriocsharp
{
    internal class ClassFactura


    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBNaturVida"].ConnectionString);

        public int Numero { get; set; }
        public DateTime Fecha { get; set; }
        public int Cliente { get; set; }
        public int ValorTotal { get; set; }
        public int Vendedor { get; set; }

        public ClassFactura(DateTime _fecha,int _cliente, int _valorTotal , int _vendedor)
            
        {
            this.Fecha= _fecha;
            this.Cliente= _cliente;
            this.ValorTotal = _valorTotal;
            this.Vendedor = _vendedor;

        
        }

        public int Registrar()
        {
            int UltimaFactura = 0;
            try
            {
                using (var command = new SqlCommand("SP_RegistrarProducto", connection))
                {
                    command.Parameters.AddWithValue("@Fecha", this.Fecha);
                    command.Parameters.AddWithValue("@Cliente", this.Cliente);
                    command.Parameters.AddWithValue("@ValorTotal", this.ValorTotal);
                    command.Parameters.AddWithValue("@Vendedor", this.Vendedor);
                    command.Parameters.Add("@UltimaFactura", SqlDbType.Int).Direction= ParameterDirection.Output;
                    command.CommandType= CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                    UltimaFactura= Convert.ToInt32(command.Parameters["@UltimaFactura"].Value.ToString());
                    connection.Close();
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                return UltimaFactura;
            }

            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();


                }
            }
            return UltimaFactura;
        }
    }
    
}
