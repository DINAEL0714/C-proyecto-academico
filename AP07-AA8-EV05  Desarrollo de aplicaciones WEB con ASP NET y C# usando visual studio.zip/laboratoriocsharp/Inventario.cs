﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laboratoriocsharp
{
    public partial class frminventario : Form
    {
        public frminventario()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnconsultar_Click(object sender, EventArgs e)
        {
            var Productos = new ClassProducto();
            var Tabla = Productos.Listar();
            var NumeroFilas = Tabla.Rows.Count;
            if (NumeroFilas>0)
            {
                for (int i = 0; i<NumeroFilas; i++)
                {
                    String Codigo = Tabla.Rows[i][0].ToString();
                    String Descripcion = Tabla.Rows[i][1].ToString();
                    String Valor = Tabla.Rows[i][2].ToString();
                    String Cantidad = Tabla.Rows[i][3].ToString();
                    String Nombre = Tabla.Rows[i][4].ToString();


                    datagridinv.Rows.Add(Codigo, Descripcion, Valor, Cantidad, Nombre);
                }
            }
        }
    }
}
