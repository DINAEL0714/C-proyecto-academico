﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace laboratoriocsharp
{
    internal class ClassProducto : IFunciones
    {


        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBNaturVida"].ConnectionString);



        public int Codigo { get; set; }
        public String Nombre { get; set; }
        public String Descripcion { get; set; }
        public int Valor { get; set; }
        public int Cantidad { get; set; }
        public ClassProducto()
        {

        }


        public ClassProducto(int _codigo, string _nombre, string _descripcion, int _valor, int _cantidad)
        {
            this.Codigo=_codigo;
            this.Nombre=_nombre;
            this.Descripcion=_descripcion;
            this.Valor=_valor;
            this.Cantidad=_cantidad;
        }

        public int Registrar()
        {
            int estado = 0;
            try
            {
                using (var command = new SqlCommand("SP_RegistrarProducto", connection))
                {
                    command.Parameters.AddWithValue("@Codigo", this.Codigo);
                    command.Parameters.AddWithValue("@Descripcion", this.Descripcion);
                    command.Parameters.AddWithValue("@Valor", this.Valor);
                    command.Parameters.AddWithValue("@Cantidad", this.Cantidad);
                    command.Parameters.AddWithValue("@Nombre", this.Nombre);
                    command.CommandType= CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();

                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                estado=1;
            }

            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();


                }
            }
            return estado;
        }

        public bool Actualizar()
        {
            Boolean Estado;
            try
            {
                using (var command = new SqlCommand("SP_ActualizarProducto", connection))
                {
                    command.Parameters.AddWithValue("@Codigo", this.Codigo);
                    command.Parameters.AddWithValue("@Descripcion", this.Descripcion);
                    command.Parameters.AddWithValue("@Valor", this.Valor);
                    command.Parameters.AddWithValue("@Cantidad", this.Cantidad);
                    command.Parameters.AddWithValue("@Nombre", this.Nombre);
                    command.CommandType= CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    Estado=true;
                    System.Windows.Forms.MessageBox.Show("El articulo se actualizo correctamente");
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                Estado=false;
            }

            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();


                }
            }
            return Estado;
        }


        public DataTable BuscarPorCodigo(int Codigo)
        {
            var tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("SP_ConsultarProducto", connection))
                {
                    adaptador.SelectCommand.Parameters.AddWithValue("@Codigo", Codigo);
                    adaptador.SelectCommand.CommandType= CommandType.StoredProcedure;
                    adaptador.Fill(tabla);

                }
            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();

                }

            }
            return tabla;

        }

        public bool eliminar(int Codigo)
        {
            Boolean Estado;
            try
            {
                using (var command = new SqlCommand("SP_EliminarProducto", connection))
                {
                    command.Parameters.AddWithValue("@Codigo", Codigo);
                    command.CommandType= CommandType.StoredProcedure;
                    connection.Open();
                    command.ExecuteNonQuery();
                    Estado = true;
                    connection.Close();
                    System.Windows.Forms.MessageBox.Show("El producto se elimino correctamente");
                    connection.Close();


                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);
                Estado=false;
            }

            finally
            {
                if (connection.State== ConnectionState.Open)
                {
                    connection.Close();


                }
            }
            return Estado;
        }

        public DataTable Listar()
        {
            var tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("select * from Productos", connection))
                {
                    adaptador.SelectCommand.CommandType=CommandType.Text;
                    adaptador.Fill(tabla);

                }
            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            return tabla;
        }
    }
}
    
