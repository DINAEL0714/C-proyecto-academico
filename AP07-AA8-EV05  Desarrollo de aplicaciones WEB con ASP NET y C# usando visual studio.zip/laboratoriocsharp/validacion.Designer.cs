﻿namespace laboratoriocsharp
{
    partial class frmGestionar
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblusuario = new System.Windows.Forms.TextBox();
            this.btningresar = new System.Windows.Forms.Button();
            this.lbnmensaje = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblcontraseña = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Lime;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(462, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sistema de Informacion Tienda Naturista NaturVida";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(47, 98);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(70, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Usuario";
            // 
            // lblusuario
            // 
            this.lblusuario.Location = new System.Drawing.Point(155, 98);
            this.lblusuario.Name = "lblusuario";
            this.lblusuario.Size = new System.Drawing.Size(278, 20);
            this.lblusuario.TabIndex = 2;
            // 
            // btningresar
            // 
            this.btningresar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btningresar.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btningresar.Location = new System.Drawing.Point(225, 223);
            this.btningresar.Name = "btningresar";
            this.btningresar.Size = new System.Drawing.Size(120, 54);
            this.btningresar.TabIndex = 3;
            this.btningresar.Text = "Ingresar";
            this.btningresar.UseVisualStyleBackColor = false;
            this.btningresar.Click += new System.EventHandler(this.btningresar_Click);
            // 
            // lbnmensaje
            // 
            this.lbnmensaje.AutoSize = true;
            this.lbnmensaje.BackColor = System.Drawing.SystemColors.Control;
            this.lbnmensaje.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbnmensaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnmensaje.ForeColor = System.Drawing.Color.IndianRed;
            this.lbnmensaje.Location = new System.Drawing.Point(178, 316);
            this.lbnmensaje.Name = "lbnmensaje";
            this.lbnmensaje.Size = new System.Drawing.Size(224, 20);
            this.lbnmensaje.TabIndex = 4;
            this.lbnmensaje.Text = "Usuario y Contraseña incorrecta";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Contraseña";
            // 
            // lblcontraseña
            // 
            this.lblcontraseña.Location = new System.Drawing.Point(155, 164);
            this.lblcontraseña.Name = "lblcontraseña";
            this.lblcontraseña.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblcontraseña.Size = new System.Drawing.Size(278, 20);
            this.lblcontraseña.TabIndex = 6;
            this.lblcontraseña.UseSystemPasswordChar = true;
            // 
            // frmGestionar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 406);
            this.Controls.Add(this.lblcontraseña);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbnmensaje);
            this.Controls.Add(this.btningresar);
            this.Controls.Add(this.lblusuario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmGestionar";
            this.Text = "Gestionar Persona";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lblusuario;
        private System.Windows.Forms.Button btningresar;
        private System.Windows.Forms.Label lbnmensaje;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox lblcontraseña;
    }
}

