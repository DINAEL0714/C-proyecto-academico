﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Configuration;

namespace laboratoriocsharp
{
    internal class ClassFunciones
    {
        SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBNaturVida"].ConnectionString);

        public DataTable ListarProductos()
        {
            var tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("select  proCodigo  from Productos", connection))
                {
                    adaptador.SelectCommand.CommandType=CommandType.Text;
                    adaptador.Fill(tabla);

                }
            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            return tabla;
        }

        public DataTable ListarCliente()
        {
            var tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("select cliid, cliNombre from Cliente", connection))
                {
                    adaptador.SelectCommand.CommandType= CommandType.Text;
                    adaptador.Fill(tabla);
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            return tabla;
        }
        public DataTable ListarVendedores()
        {
            var tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("select Venid, venUsuario from Vendedores", connection))
                {
                    adaptador.SelectCommand.CommandType= CommandType.Text;
                    adaptador.Fill(tabla);
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            return tabla;
        }
        public int ConsultarPrecio(int Codigo) 
        {
            int Precio = 0;
            DataTable tabla = new DataTable();
            try
            {
                using (var adaptador = new SqlDataAdapter("select proValor from Productos where procodigo="+Codigo, connection))
                {
                    adaptador.SelectCommand.CommandType= CommandType.Text;
                    adaptador.Fill(tabla);
                    Precio= Convert.ToInt16(tabla.Rows[0][0]);
                }

            }
            catch (SqlException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }
            return Precio;
        }

    }

}
